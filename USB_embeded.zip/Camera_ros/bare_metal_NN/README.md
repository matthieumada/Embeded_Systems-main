# change to directory
cd ~/Camera

# compile code
gcc -O2 nn_model.c weights.c -o nn_test -lm

# run code
# PC      ./nn_test /home/gregsten/Documents/Embedded_Sys_AI/test_pgm/000009_0.278.pgm
./nn_test /home/mp4d/Camera/pictures/001203_0.148.pgm
./nn_test /home/mp4d/Camera/pictures/000147_0.354.pgm

