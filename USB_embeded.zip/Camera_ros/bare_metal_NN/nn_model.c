// nn_model.c  (v2 for grayscale + GAP + single Dense)
#include <stdint.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>  

#include "weights.h"


// ======= MODEL PARAMS (ADAPT TO YOUR TRAINING SETUP) =======
#define IMG_SIZE       80   // <-- set to your real IMG_SIZE
#define IN_CH          1     // GRAYSCALE input

#define KSIZE          3
#define POOL_SIZE      2

// New conv channel sizes: 8 -> 16 -> 32
#define CONV1_OUT_CH   8
#define CONV2_OUT_CH   16
#define CONV3_OUT_CH   32

#define DENSE_UNITS    1     // final Dense(1, sigmoid)

// ======= DERIVED SHAPES (Keras: padding='valid', pool 2x2, stride 2) =======
#define CONV1_OUT_H    (IMG_SIZE - KSIZE + 1)
#define CONV1_OUT_W    (IMG_SIZE - KSIZE + 1)
#define POOL1_OUT_H    (CONV1_OUT_H / POOL_SIZE)
#define POOL1_OUT_W    (CONV1_OUT_W / POOL_SIZE)

#define CONV2_OUT_H    (POOL1_OUT_H - KSIZE + 1)
#define CONV2_OUT_W    (POOL1_OUT_W - KSIZE + 1)
#define POOL2_OUT_H    (CONV2_OUT_H / POOL_SIZE)
#define POOL2_OUT_W    (CONV2_OUT_W / POOL_SIZE)

#define CONV3_OUT_H    (POOL2_OUT_H - KSIZE + 1)
#define CONV3_OUT_W    (POOL2_OUT_W - KSIZE + 1)
#define POOL3_OUT_H    (CONV3_OUT_H / POOL_SIZE)
#define POOL3_OUT_W    (CONV3_OUT_W / POOL_SIZE)

// After GlobalAveragePooling2D, vector size = number of channels
#define GAP_SIZE       (CONV3_OUT_CH)

// ======= TEMP BUFFERS (GLOBAL STATIC TO LIVE IN .bss) =======
static float buf_conv1[CONV1_OUT_H * CONV1_OUT_W * CONV1_OUT_CH];
static float buf_pool1[POOL1_OUT_H * POOL1_OUT_W * CONV1_OUT_CH];

static float buf_conv2[CONV2_OUT_H * CONV2_OUT_W * CONV2_OUT_CH];
static float buf_pool2[POOL2_OUT_H * POOL2_OUT_W * CONV2_OUT_CH];

static float buf_conv3[CONV3_OUT_H * CONV3_OUT_W * CONV3_OUT_CH];
static float buf_pool3[POOL3_OUT_H * POOL3_OUT_W * CONV3_OUT_CH];

static float buf_gap[GAP_SIZE];    // result of GlobalAveragePooling2D
static float buf_fc[DENSE_UNITS];  // final Dense output

// ======= HELPERS =======

// NHWC indexing: (y, x, c) in [H, W, C]
static inline float get_nhwc(const float *data, int h, int w, int c,
                             int H, int W, int C)
{
    (void)H; (void)W; (void)C;
    return data[(h * W + w) * C + c];
}

static inline void set_nhwc(float *data, int h, int w, int c,
                            int H, int W, int C, float v)
{
    (void)H; (void)W; (void)C;
    data[(h * W + w) * C + c] = v;
}

// Conv kernel layout = Keras layout: [kh, kw, in_c, out_c] flattened (C order)
static inline float get_conv_kernel(const float *kernel,
                                    int kh, int kw, int in_c, int out_c,
                                    int in_channels, int out_channels)
{
    int idx = (((kh * KSIZE + kw) * in_channels) + in_c) * out_channels + out_c;
    return kernel[idx];
}

static inline float relu(float x)
{
    return x > 0.0f ? x : 0.0f;
}

static inline float sigmoid(float x)
{
    return 1.0f / (1.0f + expf(-x));
}



// Very simple PGM (P5) loader for 80x80 8-bit grayscale images.
// It fills 'out' with floats in [0,1], NHWC layout (HWC actually, C=1).
static int load_pgm_grayscale(const char *path, float *out)
{
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "Error: cannot open file '%s'\n", path);
        return -1;
    }

    // Read magic number (should be "P5")
    char header[3] = {0};
    if (fscanf(f, "%2s", header) != 1) {
        fprintf(stderr, "Error: failed to read magic number\n");
        fclose(f);
        return -1;
    }

    if (strcmp(header, "P5") != 0) {
        fprintf(stderr, "Error: '%s' is not a binary PGM (P5)\n", path);
        fclose(f);
        return -1;
    }

    int width = 0, height = 0, maxval = 0;

    // Skip comments and read width, height
    int c = fgetc(f);
    while (c == '#') {
        // Skip comment line
        while (c != '\n' && c != EOF) {
            c = fgetc(f);
        }
        c = fgetc(f);
    }
    ungetc(c, f);

    if (fscanf(f, "%d %d", &width, &height) != 2) {
        fprintf(stderr, "Error: failed to read width/height from '%s'\n", path);
        fclose(f);
        return -1;
    }

    if (fscanf(f, "%d", &maxval) != 1) {
        fprintf(stderr, "Error: failed to read maxval from '%s'\n", path);
        fclose(f);
        return -1;
    }

    if (maxval != 255) {
        fprintf(stderr, "Error: maxval=%d not supported (expected 255)\n", maxval);
        fclose(f);
        return -1;
    }

    // Skip single whitespace after maxval
    fgetc(f);

    if (width != IMG_SIZE || height != IMG_SIZE) {
        fprintf(stderr, "Error: expected %dx%d image, got %dx%d\n",
                IMG_SIZE, IMG_SIZE, width, height);
        fclose(f);
        return -1;
    }

    size_t num_pixels = (size_t)width * (size_t)height;
    uint8_t *tmp = (uint8_t *)malloc(num_pixels);
    if (!tmp) {
        fprintf(stderr, "Error: out of memory\n");
        fclose(f);
        return -1;
    }

    size_t read_bytes = fread(tmp, 1, num_pixels, f);
    fclose(f);

    if (read_bytes != num_pixels) {
        fprintf(stderr, "Error: expected %zu bytes, read %zu\n",
                num_pixels, read_bytes);
        free(tmp);
        return -1;
    }

    // Convert to float in [0,1], NHWC with C=1
    for (int y = 0; y < IMG_SIZE; ++y) {
        for (int x = 0; x < IMG_SIZE; ++x) {
            int idx = y * IMG_SIZE + x;
            float v = (float)tmp[idx] / 255.0f;
            out[(idx * IN_CH) + 0] = v;  // IN_CH = 1
        }
    }

    free(tmp);
    return 0;
}




// ======= LAYER IMPLEMENTATIONS =======

// Conv2D with 3x3 kernel, stride 1, padding='valid', followed by ReLU.
// input:  [in_h, in_w, in_c]
// output: [out_h = in_h-2, out_w = in_w-2, out_c]
static void conv2d_relu_layer(const float *input,
                              int in_h, int in_w, int in_c,
                              const float *kernel, // [3,3,in_c,out_c] flat
                              const float *bias,   // [out_c]
                              int out_c,
                              float *output)
{
    int out_h = in_h - KSIZE + 1;
    int out_w = in_w - KSIZE + 1;

    for (int y = 0; y < out_h; ++y)
    {
        for (int x = 0; x < out_w; ++x)
        {
            for (int oc = 0; oc < out_c; ++oc)
            {
                float sum = bias[oc];

                for (int kh = 0; kh < KSIZE; ++kh)
                {
                    for (int kw = 0; kw < KSIZE; ++kw)
                    {
                        int in_y = y + kh;
                        int in_x = x + kw;

                        for (int ic = 0; ic < in_c; ++ic)
                        {
                            float v = get_nhwc(input, in_y, in_x, ic,
                                               in_h, in_w, in_c);
                            float w = get_conv_kernel(kernel,
                                                      kh, kw, ic, oc,
                                                      in_c, out_c);
                            sum += v * w;
                        }
                    }
                }

                sum = relu(sum);
                set_nhwc(output, y, x, oc, out_h, out_w, out_c, sum);
            }
        }
    }
}

// MaxPooling2D with pool_size=2x2, stride=2, no padding.
static void maxpool2d_layer(const float *input,
                            int in_h, int in_w, int channels,
                            float *output)
{
    int out_h = in_h / POOL_SIZE;
    int out_w = in_w / POOL_SIZE;

    for (int y = 0; y < out_h; ++y)
    {
        for (int x = 0; x < out_w; ++x)
        {
            for (int c = 0; c < channels; ++c)
            {
                float maxv = -FLT_MAX;

                for (int py = 0; py < POOL_SIZE; ++py)
                {
                    for (int px = 0; px < POOL_SIZE; ++px)
                    {
                        int in_y = y * POOL_SIZE + py;
                        int in_x = x * POOL_SIZE + px;
                        float v = get_nhwc(input, in_y, in_x, c,
                                           in_h, in_w, channels);
                        if (v > maxv) maxv = v;
                    }
                }

                set_nhwc(output, y, x, c, out_h, out_w, channels, maxv);
            }
        }
    }
}

// GlobalAveragePooling2D:
//
// input:  [H, W, C]
// output: [C]  (average over H*W per channel)
static void global_average_pooling2d_layer(const float *input,
                                           int H, int W, int C,
                                           float *output) // size C
{
    int spatial = H * W;

    for (int c = 0; c < C; ++c)
    {
        float sum = 0.0f;
        for (int y = 0; y < H; ++y)
        {
            for (int x = 0; x < W; ++x)
            {
                sum += get_nhwc(input, y, x, c, H, W, C);
            }
        }
        output[c] = sum / (float)spatial;
    }
}

// Dense + sigmoid
// weights layout = Keras: [in_dim, units] flattened row-major.
static void dense_sigmoid_layer(const float *input,
                                int in_dim,
                                const float *weights,
                                const float *bias,
                                int units,
                                float *output)
{
    // units should be 1 here, but we keep it general
    for (int u = 0; u < units; ++u)
    {
        float sum = bias[u];
        for (int i = 0; i < in_dim; ++i)
        {
            float w = weights[i * units + u];
            sum += input[i] * w;
        }
        output[u] = sigmoid(sum);
    }
}

// ======= FULL FORWARD PASS =======
// input_image: pointer to IMG_SIZE*IMG_SIZE*1 floats in NHWC order (HWC actually)
// returns probability in [0,1]
float nn_predict(const float *input_image)
{
    // 1) Conv2D(8, 3x3, relu)
    conv2d_relu_layer(input_image,
                      IMG_SIZE, IMG_SIZE, IN_CH,
                      conv1_kernel, conv1_bias, CONV1_OUT_CH,
                      buf_conv1);

    // 2) MaxPool
    maxpool2d_layer(buf_conv1,
                    CONV1_OUT_H, CONV1_OUT_W, CONV1_OUT_CH,
                    buf_pool1);

    // 3) Conv2D(16, 3x3, relu)
    conv2d_relu_layer(buf_pool1,
                      POOL1_OUT_H, POOL1_OUT_W, CONV1_OUT_CH,
                      conv2_kernel, conv2_bias, CONV2_OUT_CH,
                      buf_conv2);

    // 4) MaxPool
    maxpool2d_layer(buf_conv2,
                    CONV2_OUT_H, CONV2_OUT_W, CONV2_OUT_CH,
                    buf_pool2);

    // 5) Conv2D(32, 3x3, relu)
    conv2d_relu_layer(buf_pool2,
                      POOL2_OUT_H, POOL2_OUT_W, CONV2_OUT_CH,
                      conv3_kernel, conv3_bias, CONV3_OUT_CH,
                      buf_conv3);

    // 6) MaxPool
    maxpool2d_layer(buf_conv3,
                    CONV3_OUT_H, CONV3_OUT_W, CONV3_OUT_CH,
                    buf_pool3);

    // 7) GlobalAveragePooling2D
    global_average_pooling2d_layer(buf_pool3,
                                   POOL3_OUT_H, POOL3_OUT_W, CONV3_OUT_CH,
                                   buf_gap);

    // 8) Dense(1, sigmoid)
    dense_sigmoid_layer(buf_gap, GAP_SIZE,
                        dense_kernel, dense_bias,
                        DENSE_UNITS,
                        buf_fc);

    return buf_fc[0];
}

// Example main (for a board that just calls nn_predict once)
int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input_image.pgm\n", argv[0]);
        return 1;
    }
    const char *image_path = argv[1];
    
    static float input_image[IMG_SIZE * IMG_SIZE * IN_CH];
    if (load_pgm_grayscale(image_path, input_image) != 0) {
        fprintf(stderr, "Failed to load image '%s'\n", image_path);
        return 1;
    }
    
    float prob = nn_predict(input_image);
    printf("nn_predict(\"%s\") = %.6f\n", image_path, prob);
    
    return 0;
}

