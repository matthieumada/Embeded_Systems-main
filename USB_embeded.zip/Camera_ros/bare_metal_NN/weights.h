#pragma once
#include <stdint.h>

extern const float conv1_kernel[];
extern const float conv1_bias[];
extern const float conv2_kernel[];
extern const float conv2_bias[];
extern const float conv3_kernel[];
extern const float conv3_bias[];
extern const float dense_kernel[];
extern const float dense_bias[];
