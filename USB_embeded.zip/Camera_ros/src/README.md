# start ros 
source /opt/ros/foxy/setup.bash

# create ros package
ros2 pkg create --build-type ament_cmake \
  --dependencies rclcpp sensor_msgs cv_bridge image_transport \
  my_image_pipeline


# /image_raw → /image/pgm_80x80 (resize)

# /image/pgm_80x80 → /image/normalized (normalize)

# /image/normalized → disk (PGM files, max 10 in dir)


# code all files
#   pgm_resizer_node.cpp
<!--    Input encoding is mono8 (8-bit grayscale)
        Topic: /image_raw
        Output topic: /image/pgm_80x80
        Resize using nearest neighbour (very cheap) -->
#   normalize_node.cpp
#   image_saver_node.cpp
<!--    Subscribe to /image/normalized
        Write a binary PGM (P5) file by hand
        Limit directory to 10 .pgm files using std::filesystem -->

# install
sudo apt install ros-foxy-usb-cam




# build
source /opt/ros/foxy/setup.bash
cd ~/Camera
colcon build --packages-select image_pipeline \
  --executor sequential \
  --parallel-workers 1 \
  --cmake-args -DCMAKE_BUILD_TYPE=Release

# new Terminal launch
source /opt/ros/foxy/setup.bash
cd ~/Camera
source install/setup.bash
ros2 launch image_pipeline image_pipeline.launch.py


# watch nn output
source /opt/ros/foxy/setup.bash
cd ~/Camera
source install/setup.bash

ros2 topic echo /nn/result



source /opt/ros/foxy/setup.bash
cd ~/Camera
source install/setup.bash
ros2 topic echo /nn/result


<!-- 
# Terminal usb_cam_node_exe
source /opt/ros/foxy/setup.bash
cd ~/Camera
source install/setup.bash
ros2 run usb_cam usb_cam_node_exe \
  --ros-args \
    -p video_device:="/dev/video0" \
    -p image_width:=640 \
    -p image_height:=480 \
    -p framerate:=25.0 \
    -p pixel_format:="yuyv" \
    -p io_method:="mmap"


# Terminal pgm_resizer_node
source /opt/ros/foxy/setup.bash
cd ~/Camera
source install/setup.bash
ros2 run image_pipeline pgm_resizer_node


# Terminal ormalize_node
source /opt/ros/foxy/setup.bash
cd ~/Camera
source install/setup.bash
ros2 run image_pipeline normalize_node


# Terminal image_saver_node
source /opt/ros/foxy/setup.bash
cd ~/Camera
source install/setup.bash
ros2 run image_pipeline image_saver_node \
  --ros-args -p output_dir:=/tmp/pgm_images -->
