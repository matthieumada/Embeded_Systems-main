#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>

#include <vector>
#include <string>
#include <algorithm>
#include <cstdint>

class PGMResizerNode : public rclcpp::Node
{
public:
  PGMResizerNode() : Node("pgm_resizer_node")
  {
    width_  = this->declare_parameter<int>("width", 80);
    height_ = this->declare_parameter<int>("height", 80);

    // subscribe to the raw camera image
    sub_ = this->create_subscription<sensor_msgs::msg::Image>(
      "/image_raw", 10,
      std::bind(&PGMResizerNode::image_callback, this, std::placeholders::_1));

    // publish resized grayscale
    pub_ = this->create_publisher<sensor_msgs::msg::Image>("/image/pgm_80x80", 10);
  }

private:
  // helpers to convert to mono8

  void from_mono8(const sensor_msgs::msg::Image &msg,
                  std::vector<uint8_t> &gray,
                  uint32_t &w, uint32_t &h)
  {
    w = msg.width;
    h = msg.height;
    gray = msg.data;  // already mono8
  }

  void from_rgb8(const sensor_msgs::msg::Image &msg,
                 std::vector<uint8_t> &gray,
                 uint32_t &w, uint32_t &h)
  {
    w = msg.width;
    h = msg.height;

    const auto &src = msg.data;
    const size_t num_pixels = static_cast<size_t>(w) * h;
    if (src.size() < num_pixels * 3) {
      RCLCPP_WARN(rclcpp::get_logger("pgm_resizer_node"), "RGB image data too small");
      return;
    }

    gray.resize(num_pixels);
    // assume msg.encoding is "rgb8"
    for (size_t i = 0; i < num_pixels; ++i) {
      size_t j = i * 3;
      uint8_t r = src[j + 0];
      uint8_t g = src[j + 1];
      uint8_t b = src[j + 2];
      // simple luminance: 0.299 R + 0.587 G + 0.114 B
      uint8_t y = static_cast<uint8_t>(
        0.299f * r + 0.587f * g + 0.114f * b);
      gray[i] = y;
    }
  }

  void from_bgr8(const sensor_msgs::msg::Image &msg,
                 std::vector<uint8_t> &gray,
                 uint32_t &w, uint32_t &h)
  {
    w = msg.width;
    h = msg.height;

    const auto &src = msg.data;
    const size_t num_pixels = static_cast<size_t>(w) * h;
    if (src.size() < num_pixels * 3) {
      RCLCPP_WARN(rclcpp::get_logger("pgm_resizer_node"), "BGR image data too small");
      return;
    }

    gray.resize(num_pixels);
    // assume msg.encoding is "bgr8"
    for (size_t i = 0; i < num_pixels; ++i) {
      size_t j = i * 3;
      uint8_t b = src[j + 0];
      uint8_t g = src[j + 1];
      uint8_t r = src[j + 2];
      uint8_t y = static_cast<uint8_t>(
        0.299f * r + 0.587f * g + 0.114f * b);
      gray[i] = y;
    }
  }

  // YUV422 YUYV family: yuv422_yuy2 / yuyv / yuyv422 / YUYV
  void from_yuyv(const sensor_msgs::msg::Image &msg,
                 std::vector<uint8_t> &gray,
                 uint32_t &w, uint32_t &h)
  {
    w = msg.width;
    h = msg.height;

    const auto &src = msg.data;
    const size_t num_pixels = static_cast<size_t>(w) * h;
    gray.resize(num_pixels);

    // Layout per row:
    // bytes: Y0 U0 Y1 V0 Y2 U1 Y3 V1 ...
    // step = 2 * width (for 8-bit)
    for (uint32_t y = 0; y < h; ++y) {
      const size_t row_offset = static_cast<size_t>(y) * msg.step;
      for (uint32_t x = 0; x < w; ++x) {
        size_t src_idx = row_offset + static_cast<size_t>(2) * x;
        if (src_idx >= src.size()) {
          continue;
        }
        uint8_t Y = src[src_idx];  // first byte of each 2-byte pixel is luma
        size_t dst_idx = static_cast<size_t>(y) * w + x;
        gray[dst_idx] = Y;
      }
    }
  }

  void image_callback(const sensor_msgs::msg::Image::SharedPtr msg)
  {
    std::vector<uint8_t> gray;
    uint32_t in_w = 0, in_h = 0;

    const std::string enc = msg->encoding;

    if (enc == "mono8") {
      from_mono8(*msg, gray, in_w, in_h);
    } else if (enc == "rgb8") {
      from_rgb8(*msg, gray, in_w, in_h);
    } else if (enc == "bgr8") {
      from_bgr8(*msg, gray, in_w, in_h);
    } else if (
        enc == "yuv422_yuy2" ||
        enc == "yuyv" ||
        enc == "yuyv422" ||
        enc == "YUYV") {
      from_yuyv(*msg, gray, in_w, in_h);
    } else {
      RCLCPP_WARN(this->get_logger(),
                  "Unsupported encoding '%s', expected mono8/rgb8/bgr8/yuv422_yuy2",
                  enc.c_str());
      return;
    }

    if (in_w == 0 || in_h == 0 || gray.empty()) {
      RCLCPP_WARN(this->get_logger(), "Invalid input image");
      return;
    }

    // nearest-neighbor scale to width_ x height_
    std::vector<uint8_t> out_data(static_cast<size_t>(width_) * height_);

    const float scale_x = static_cast<float>(in_w) / static_cast<float>(width_);
    const float scale_y = static_cast<float>(in_h) / static_cast<float>(height_);

    for (int y = 0; y < height_; ++y) {
      int src_y = static_cast<int>(y * scale_y);
      if (src_y >= static_cast<int>(in_h)) src_y = in_h - 1;
      for (int x = 0; x < width_; ++x) {
        int src_x = static_cast<int>(x * scale_x);
        if (src_x >= static_cast<int>(in_w)) src_x = in_w - 1;

        size_t src_idx = static_cast<size_t>(src_y) * in_w + src_x;
        size_t dst_idx = static_cast<size_t>(y) * width_ + x;
        out_data[dst_idx] = gray[src_idx];
      }
    }

    sensor_msgs::msg::Image out_msg;
    out_msg.header = msg->header;
    out_msg.height = height_;
    out_msg.width  = width_;
    out_msg.encoding = "mono8";
    out_msg.is_bigendian = 0;
    out_msg.step = width_;
    out_msg.data = std::move(out_data);

    pub_->publish(out_msg);
  }

  int width_;
  int height_;
  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr sub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr pub_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PGMResizerNode>());
  rclcpp::shutdown();
  return 0;
}
