#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>

#include <filesystem>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <iomanip>

namespace fs = std::filesystem;

class ImageSaverNode : public rclcpp::Node
{
public:
  ImageSaverNode() : Node("image_saver_node")
  {
    output_dir_ = this->declare_parameter<std::string>("output_dir", "saved_images");
    max_images_ = this->declare_parameter<int>("max_images", 10);

    if (!fs::exists(output_dir_)) {
      fs::create_directories(output_dir_);
    }

    sub_ = this->create_subscription<sensor_msgs::msg::Image>(
      "/image/normalized", 10,
      std::bind(&ImageSaverNode::image_callback, this, std::placeholders::_1));
  }

private:
  void image_callback(const sensor_msgs::msg::Image::SharedPtr msg)
  {
    if (msg->encoding != "mono8") {
      RCLCPP_WARN(this->get_logger(), "Expected mono8 image, got %s",
                  msg->encoding.c_str());
      return;
    }

    if (msg->data.empty()) {
      RCLCPP_WARN(this->get_logger(), "Empty image");
      return;
    }

    const uint32_t width = msg->width;
    const uint32_t height = msg->height;

    // Build filename using timestamp
    auto now = this->get_clock()->now();
    auto ns = now.nanoseconds();
    std::ostringstream ss;
    ss << "img_" << ns << ".pgm";
    fs::path filepath = fs::path(output_dir_) / ss.str();

    // Write PGM P5 header + data
    std::ofstream ofs(filepath, std::ios::binary);
    if (!ofs) {
      RCLCPP_ERROR(this->get_logger(), "Failed to open file: %s",
                   filepath.string().c_str());
      return;
    }

    ofs << "P5\n" << width << " " << height << "\n255\n";
    ofs.write(reinterpret_cast<const char*>(msg->data.data()),
              static_cast<std::streamsize>(msg->data.size()));
    ofs.close();

    if (!ofs) {
      RCLCPP_ERROR(this->get_logger(), "Failed to write file: %s",
                   filepath.string().c_str());
      return;
    }

    RCLCPP_INFO(this->get_logger(), "Saved %s", filepath.string().c_str());

    enforce_max_images();
  }

  void enforce_max_images()
  {
    std::vector<fs::directory_entry> files;
    for (const auto &entry : fs::directory_iterator(output_dir_)) {
      if (entry.is_regular_file() && entry.path().extension() == ".pgm") {
        files.push_back(entry);
      }
    }

    if (files.size() <= static_cast<size_t>(max_images_)) {
      return;
    }

    std::sort(files.begin(), files.end(),
              [](const fs::directory_entry &a, const fs::directory_entry &b) {
                return fs::last_write_time(a) < fs::last_write_time(b);
              });

    size_t to_delete = files.size() - static_cast<size_t>(max_images_);
    for (size_t i = 0; i < to_delete; ++i) {
      try {
        fs::remove(files[i].path());
        RCLCPP_INFO(this->get_logger(), "Deleted old image: %s",
                    files[i].path().string().c_str());
      } catch (const std::exception &e) {
        RCLCPP_ERROR(this->get_logger(), "Failed to delete %s: %s",
                     files[i].path().string().c_str(), e.what());
      }
    }
  }

  std::string output_dir_;
  int max_images_;
  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr sub_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ImageSaverNode>());
  rclcpp::shutdown();
  return 0;
}
