#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <algorithm>
#include <cstdint>

class NormalizeNode : public rclcpp::Node
{
public:
  NormalizeNode() : Node("normalize_node")
  {
    sub_ = this->create_subscription<sensor_msgs::msg::Image>(
      "/image/pgm_80x80", 10,
      std::bind(&NormalizeNode::image_callback, this, std::placeholders::_1));

    pub_ = this->create_publisher<sensor_msgs::msg::Image>("/image/normalized", 10);
  }

private:
  void image_callback(const sensor_msgs::msg::Image::SharedPtr msg)
  {
    if (msg->encoding != "mono8") {
      RCLCPP_WARN(this->get_logger(), "Expected mono8 image, got %s",
                  msg->encoding.c_str());
      return;
    }

    if (msg->data.empty()) {
      RCLCPP_WARN(this->get_logger(), "Empty image");
      return;
    }

    auto data = msg->data;  // copy

    auto minmax = std::minmax_element(data.begin(), data.end());
    uint8_t min_val = *minmax.first;
    uint8_t max_val = *minmax.second;

    if (max_val == min_val) {
      std::fill(data.begin(), data.end(), 0);
    } else {
      for (auto &v : data) {
        float norm = static_cast<float>(v - min_val) /
                     static_cast<float>(max_val - min_val);
        v = static_cast<uint8_t>(norm * 255.0f);
      }
    }

    sensor_msgs::msg::Image out = *msg;
    out.data = std::move(data);
    pub_->publish(out);
  }

  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr sub_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr pub_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<NormalizeNode>());
  rclcpp::shutdown();
  return 0;
}
