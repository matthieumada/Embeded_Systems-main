#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <std_msgs/msg/string.hpp>

#include <filesystem>
#include <fstream>
#include <cstdio>
#include <memory>
#include <array>
#include <chrono>
#include <sstream>
#include <string>

namespace fs = std::filesystem;

class NNInferenceNode : public rclcpp::Node
{
public:
  NNInferenceNode() : Node("nn_inference_node")
  {
    nn_exec_ = this->declare_parameter<std::string>(
      "nn_executable", "/home/mp4d/Camera/nn_test");
    temp_dir_ = this->declare_parameter<std::string>(
      "temp_dir", "/tmp/nn_inputs");
    process_every_n_ = this->declare_parameter<int>(
      "process_every_n", 1);  // process every frame by default

    if (!fs::exists(temp_dir_)) {
      fs::create_directories(temp_dir_);
    }

    sub_ = this->create_subscription<sensor_msgs::msg::Image>(
      "/image/normalized", 10,
      std::bind(&NNInferenceNode::image_callback, this, std::placeholders::_1));

    pub_ = this->create_publisher<std_msgs::msg::String>("/nn/result", 10);

    RCLCPP_INFO(this->get_logger(),
                "NNInferenceNode started. Executable: %s, temp_dir: %s",
                nn_exec_.c_str(), temp_dir_.c_str());
  }

private:
  void image_callback(const sensor_msgs::msg::Image::SharedPtr msg)
  {
    frame_count_++;
    if (process_every_n_ > 1 && (frame_count_ % process_every_n_) != 0) {
      // skip this frame to lighten the load
      return;
    }

    if (msg->encoding != "mono8") {
      RCLCPP_WARN(this->get_logger(),
                  "Expected mono8 normalized image, got '%s'",
                  msg->encoding.c_str());
      return;
    }

    if (msg->width == 0 || msg->height == 0 || msg->data.empty()) {
      RCLCPP_WARN(this->get_logger(), "Invalid image data");
      return;
    }

    // 1) Write image as PGM file
    fs::path filepath = make_temp_pgm(*msg);
    if (filepath.empty()) {
      RCLCPP_ERROR(this->get_logger(), "Failed to create temp PGM file");
      return;
    }

    // 2) Run nn_executable <filepath> and capture stdout
    std::string output;
    bool ok = run_nn(filepath.string(), output);

    // Optionally delete temp file
    try {
      fs::remove(filepath);
    } catch (...) {
      // ignore
    }

    if (!ok) {
      RCLCPP_ERROR(this->get_logger(), "NN executable failed");
      return;
    }

    // 3) Publish result as a String
    auto msg_out = std_msgs::msg::String();
    msg_out.data = output;
    pub_->publish(msg_out);
  }

  fs::path make_temp_pgm(const sensor_msgs::msg::Image &img)
  {
    // Build filename using timestamp
    auto now = this->get_clock()->now();
    auto ns = now.nanoseconds();
    std::ostringstream ss;
    ss << "nn_in_" << ns << ".pgm";
    fs::path filepath = fs::path(temp_dir_) / ss.str();

    std::ofstream ofs(filepath, std::ios::binary);
    if (!ofs) {
      RCLCPP_ERROR(this->get_logger(), "Failed to open temp file: %s",
                   filepath.string().c_str());
      return {};
    }

    uint32_t width  = img.width;
    uint32_t height = img.height;

    // PGM header (binary P5)
    ofs << "P5\n" << width << " " << height << "\n255\n";
    ofs.write(reinterpret_cast<const char*>(img.data.data()),
              static_cast<std::streamsize>(img.data.size()));
    ofs.close();

    if (!ofs.good()) {
      RCLCPP_ERROR(this->get_logger(), "Failed to write temp PGM file: %s",
                   filepath.string().c_str());
      return {};
    }

    return filepath;
  }

  bool run_nn(const std::string &image_path, std::string &output)
  {
    // command: "<nn_exec_> <image_path>"
    std::string cmd = nn_exec_ + " " + image_path;

    // Use popen to capture stdout
    std::array<char, 256> buffer{};
    output.clear();

    FILE* pipe = popen(cmd.c_str(), "r");
    if (!pipe) {
      RCLCPP_ERROR(this->get_logger(), "Failed to run command: %s", cmd.c_str());
      return false;
    }

    while (fgets(buffer.data(), buffer.size(), pipe) != nullptr) {
      output += buffer.data();
    }

    int ret = pclose(pipe);
    if (ret == -1) {
      RCLCPP_ERROR(this->get_logger(), "Error when closing pipe for command: %s", cmd.c_str());
      return false;
    }

    // ret contains exit status << 8; 0 means success
    if (WIFEXITED(ret) && WEXITSTATUS(ret) == 0) {
      RCLCPP_INFO(this->get_logger(), "NN executed successfully");
      return true;
    } else {
      RCLCPP_WARN(this->get_logger(),
                  "NN exited with code %d, output: %s",
                  WEXITSTATUS(ret), output.c_str());
      return false;
    }
  }

  std::string nn_exec_;
  std::string temp_dir_;
  int process_every_n_;
  uint64_t frame_count_ {0};

  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr sub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr pub_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<NNInferenceNode>());
  rclcpp::shutdown();
  return 0;
}
