from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():

    usb_cam = Node(
        package='usb_cam',
        executable='usb_cam_node_exe',
        name='usb_cam',
        output='screen',
        parameters=[{
            'video_device': '/dev/video0',
            'image_width': 640,
            'image_height': 480,
            'framerate': 25.0,
            'pixel_format': 'yuyv',
            'io_method': 'mmap',
        }]
    )

    pgm_resizer = Node(
        package='image_pipeline',
        executable='pgm_resizer_node',
        name='pgm_resizer_node',
        output='screen'
        # subscribes to /image_raw from usb_cam, publishes /image/pgm_80x80
    )

    normalize = Node(
        package='image_pipeline',
        executable='normalize_node',
        name='normalize_node',
        output='screen'
        # subscribes to /image/pgm_80x80, publishes /image/normalized
    )

    saver = Node(
        package='image_pipeline',
        executable='image_saver_node',
        name='image_saver_node',
        output='screen',
        parameters=[{
            'output_dir': '/tmp/pgm_images',
            'max_images': 10,
        }]
        # subscribes to /image/normalized and saves PGM files
    )

    nn_inference = Node(
        package='image_pipeline',
        executable='nn_inference_node',
        name='nn_inference_node',
        output='screen',
        parameters=[{
            'nn_executable': '/home/mp4d/Camera/nn_test',
            'temp_dir': '/tmp/nn_inputs',
            'process_every_n': 1,
        }]
    )

    return LaunchDescription([
        usb_cam,
        pgm_resizer,
        normalize,
        saver,
        nn_inference,
    ])
